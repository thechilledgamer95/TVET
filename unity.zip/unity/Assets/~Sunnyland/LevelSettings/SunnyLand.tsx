<?xml version="1.0" encoding="UTF-8"?>
<tileset name="SunnyLand" tilewidth="16" tileheight="16" tilecount="575" columns="25">
 <image source="../Environment/tileset.png" width="400" height="368"/>
</tileset>
